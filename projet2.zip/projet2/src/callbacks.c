#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "menu.h"

int sup =0 ;
char ident1[10] ;
int choix;
void
on_ebrbuttonconnect_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
char msg [60];
GtkWidget *username,*password,*ebrwindowen;
char user[20];
char pasw[20];
char user1[20];
char pasw1[20]; int a=0;
username = lookup_widget (button,"ebrentrylogin");
password = lookup_widget (button,"ebrentrymdp");

strcpy(user,gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw,gtk_entry_get_text(GTK_ENTRY(password)));
FILE *f;
f=fopen("utilisateur.txt","r");
while(fscanf(f,"%s %s \n",user1,pasw1)!=EOF){if (strcmp(user,user1)==0 && strcmp(pasw,pasw1)==0){ a=1;} }

if( a==1){
ebrwindowen=create_ebrwindowen();
gtk_widget_show (ebrwindowen); 
a=0; }
else {


GtkWidget *sortie;
sortie=lookup_widget(button,"ebrlabelconnect");
strcpy(msg,"identifiant ou mot de passe incorrect");
gtk_label_set_text(GTK_LABEL(sortie),msg);}




fclose(f);
}


void
on_ebrbuttonaficher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ebrwindowaffiche;
GtkWidget *treeview1;

ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");
ebrwindowaffiche=create_ebrwindowaffiche();


gtk_widget_show(ebrwindowaffiche);

treeview1=lookup_widget(ebrwindowaffiche,"treeview1");
afficher(treeview1);

}


void
on_ebrbuttonajout_clicked              (GtkWidget        *button,
                                        gpointer         user_data)
{
  GtkWidget *ebrwindowajouter;
  ebrwindowajouter = create_ebrwindowajouter ();
  gtk_widget_show (ebrwindowajouter);
}


void
on_ebrbuttonchercher_clicked           (GtkWidget        *button,
                                        gpointer         user_data)
{  GtkWidget *ebrwindowchercher;
  ebrwindowchercher = create_ebrwindowchercher ();
  gtk_widget_show (ebrwindowchercher);
}


void
on_ebrbuttonmodifier_clicked           (GtkWidget        *button,
                                        gpointer         user_data)
{ GtkWidget *ebrwindowmodifier;
  ebrwindowmodifier = create_ebrwindowmodifier ();
  gtk_widget_show (ebrwindowmodifier);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonmeilleur_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{

FILE* f;
FILE* fm;
int a,b,na,nb;
float c,nc=1000.00;
  int l;
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char str[25];
    char date[10];
    char id[10];
char text[15];
char msg[100]="le meilleur menu est ";
GtkWidget *sortie;
sortie=lookup_widget(button,"ebrlabelme");
// GtkWidget *ebrmeilleur;
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %f\n",&a,&b,&c)!=EOF){

  if (nc>c){nc=c;
  nb=b;
  na=a;                 }
}
sprintf(text,"%d",na);
fm=fopen("menu.txt","r");

while(fscanf(fm,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
   



if (strcmp(type,"petit_dej")==0){l=1;}
else if (strcmp(type,"repas")==0){l=2;}
else if (strcmp(type,"dinner")==0){l=3;}




if ((strcmp(date,text)==0) && (nb==l)){ 

strcat(msg,nom);
 gtk_label_set_text(GTK_LABEL(sortie),msg);}
}



fclose(fm);
fclose(f);





}

//////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonsupprimer_clicked          (GtkWidget        *button,
                                        gpointer         user_data)
{GtkWidget *ebrwindowsupp;
  ebrwindowsupp = create_ebrwindowsupp ();
  gtk_widget_show (ebrwindowsupp);

}
////////////////////////////////////////////////////////////////////////////////////////////////

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar* id;
gchar* nom;
gchar* type;
gchar* entree;
gchar* suite;
gchar* dessert;
gchar* date;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&type,3,&entree,4,&suite,5,&dessert,6,&date,-1);



strcpy(ident1,id);
/////////////////////

}



}


void
on_ebrbuttonajoutermenu_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu m;
GtkWidget *input1,*input2,*spin,*input4,*input5,*input6,*input7;
GtkWidget *ebrwindowajouter;
char typea[20],date1[10];
int a;

ebrwindowajouter=lookup_widget(objet,"ebrwindowajouter");

input1=lookup_widget(objet,"ebrentryaid");
input2=lookup_widget(objet,"ebrentryanom");
if (choix==1){strcpy(typea,"petit_dej");}
if (choix==2){strcpy(typea,"repas");}
if (choix==3){strcpy(typea,"dinner");}


input4=lookup_widget(objet,"ebrentryaentree");
input5=lookup_widget(objet,"ebrentryasuite");
input6=lookup_widget(objet,"ebrentryadessert");

//input7=lookup_widget(objet,"entry2");

spin = lookup_widget(objet,"spinbutton1");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
sprintf(date1,"%d",a);



strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(m.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(m.type,typea);
strcpy(m.entree,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(m.suite,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(m.dessert,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(m.date,date1);
ajouter(m);
choix=0;

}


void
on_ebrbuttonsupp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
char a[10];
GtkWidget *input1;
GtkWidget *ebrwindowsupp;

ebrwindowsupp=lookup_widget(objet,"ebrwindowsupp");
input1=lookup_widget(objet,"ebrentrysupp");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer(a);

}


///////////////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttoncherche2_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
   GtkWidget *input, *sortie;
   char text[10];
   char msg[100];
input = lookup_widget(button,"ebrentrycherche");
sortie=lookup_widget(button,"ebrlabelmescher");
strcpy(text,gtk_entry_get_text(GTK_ENTRY(input)));
if (chercher(text)==1) {strcpy(msg,"le menu existe");}
else {strcpy(msg,"le menu n'existe pas");}

gtk_label_set_text(GTK_LABEL(sortie),msg);

}

//////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonyes_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE* f;
    char id1[10];
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    GtkWidget *input, *input1; 
    int a;
GtkWidget *combobox, *spin;
input1 = lookup_widget(button,"ebrcomboboxentrymtype");
input = lookup_widget(button,"ebrentrymid");
spin = lookup_widget(button,"ebrspinbuttonmdate");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input)));
f=fopen("menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
if (strcmp(id,id1)==0){
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymnom")),nom);            
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymentree")),entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymsuite")),suite);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymdessert")),dessert);
if(strcmp(type,"repas")==0) {a=1;}
else if (strcmp(type,"dinner")==0){a=2;}
else {a=0;}
gtk_combo_box_set_active(GTK_COMBO_BOX(input1),a);
gtk_spin_button_set_value(spin,atoi(date));

}
}

fclose(f);


}
////////////////////////////////////////////////////////////////////////////////////

void
on_ebrbuttonenregistrer_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE* ft;
FILE* f;
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char id1[10];
    char date1[10];
    char nom1[25];
    char type1[20];
    char entree1[30];
    char suite1[30];
    char dessert1[30];
   int a;
GtkWidget *combobox1, *spin;
GtkWidget *input2, *input1, *input3, *input4, *input5;
spin = lookup_widget(button,"ebrspinbuttonmdate");
combobox1 = lookup_widget(button,"ebrcomboboxentrymtype");
input1 = lookup_widget(button,"ebrentrymid");
input2 = lookup_widget(button,"ebrentrymnom");
input3 = lookup_widget(button,"ebrentrymentree");
input4 = lookup_widget(button,"ebrentrymsuite");
input5 = lookup_widget(button,"ebrentrymdessert");
//
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
sprintf(date1,"%d",a);

strcpy(type1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))) ;

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(entree1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(suite1,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(dessert1,gtk_entry_get_text(GTK_ENTRY(input5)));




f=fopen("menu.txt","r");
ft=fopen("tmp.txt","ab+");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){



if (strcmp(id,id1)==0) {fprintf(ft,"%s %s %s %s %s %s %s\n",id1,nom1,type1,entree1,suite1,dessert1,date1);}

else {fprintf(ft,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date);}
}

fclose(f);
fclose(ft);
remove("menu.txt");
rename("tmp.txt","menu.txt");
}


void
on_ebrbuttonajout1_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{ GtkWidget *ebrwindowajouter;

 ebrwindowajouter = create_ebrwindowajouter ();
  gtk_widget_show (ebrwindowajouter);

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_ebrbuttonmodifier1_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *ebrwindowmodifier;



 ebrwindowmodifier = create_ebrwindowmodifier ();
  
 gtk_widget_show (ebrwindowmodifier);

}


gboolean
on_ebrwindowmodifier_focus_in_event    (GtkWidget       *button,
                                        GdkEventFocus   *event,
                                        gpointer         user_data)
{


FILE* f;
    
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    GtkWidget *input, *input1; 
    int a;


GtkWidget *combobox, *spin;
input1 = lookup_widget(button,"ebrcomboboxentrymtype");
input = lookup_widget(button,"ebrentrymid");
spin = lookup_widget(button,"ebrspinbuttonmdate");
f=fopen("menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
if (strcmp(id,ident1)==0){
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymid")),ident1);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymnom")),nom);            
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymentree")),entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymsuite")),suite);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(button,"ebrentrymdessert")),dessert);
if(strcmp(type,"repas")==0) {a=1;}
else if (strcmp(type,"dinner")==0){a=2;}
else {a=0;}
gtk_combo_box_set_active(GTK_COMBO_BOX(input1),a);
gtk_spin_button_set_value(spin,atoi(date));


}
}

fclose(f);

  return FALSE;
}


void
on_ebrbuttondelete_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{ 
GtkWidget *ebrwindowconfsupp;
ebrwindowconfsupp = create_ebrwindowconfsupp ();
  gtk_widget_show (ebrwindowconfsupp);

}


gboolean
on_ebrwindowconfsupp_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data)
{

  return FALSE;
}


void
on_ebrbuttonsupp3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sortie;

sortie=lookup_widget(objet,"ebrlabelmsg");
char a[10];
char msg[30]="cocher pour conifrmer!";
if (sup==1)
{strcpy(a,ident1);
supprimer(a);
sup=0;}
else
gtk_label_set_text(GTK_LABEL(sortie),msg);


}


void
on_ebrchecksupp_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){sup=1;}
}



void
on_ebrradiop_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=1;
}


void
on_ebrradior_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=2;
}


void
on_ebrradiod_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=3;
}


void
on_ebrbuttonretour_clicked             (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *ebrwindowaffiche, *ebrwindowen;

ebrwindowen=lookup_widget(objet,"ebrwindowen");
ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");
gtk_widget_destroy(ebrwindowen);
gtk_widget_destroy(ebrwindowaffiche);


}


void
on_ebrbuttonrefresh_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ebrwindowaffiche, *w1, *treeview1;

w1=lookup_widget(objet,"ebrwindowaffiche");

//ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");


ebrwindowaffiche=create_ebrwindowaffiche();
gtk_widget_show(ebrwindowaffiche);
gtk_widget_hide(w1);

treeview1=lookup_widget(ebrwindowaffiche,"treeview1");

vider(treeview1);
afficher(treeview1);

}

